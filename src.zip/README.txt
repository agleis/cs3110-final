Hello! Welcome to the game of HEARTS, a fun card game for 1-4 players.

If you don't know the rules of Hearts, don't worry - just run the program and
it will tell you some of the basic rules.

To run this program, simply go to your command line and type "make setup" in
the base directory of this project (after extracting the files from the zip).
Then, simply follow the onscreen directions to have a great time!
